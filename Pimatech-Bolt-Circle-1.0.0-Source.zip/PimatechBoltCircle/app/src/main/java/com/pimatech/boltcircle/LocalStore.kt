package com.pimatech.boltcircle
import android.content.Context
import com.pimatech.boltcircle.engine.*
data class Setup(val count:Int?=6,val bc:Double?=null,val hole:Double?=12.7,val gap:Double?=50.8,val firstAngle:Double=0.0,val unit:LengthUnit=LengthUnit.INCH) {
 fun inputs()=Inputs(count,bc,hole,gap,firstAngle)
 fun solution()=BoltCircle.solve(inputs())
 fun unknown(field:Field):Setup {
  val r=runCatching{solution()}.getOrNull()
  return copy(count=if(field==Field.COUNT) null else r?.count ?: count,bc=if(field==Field.BC) null else r?.bc ?: bc,hole=if(field==Field.HOLE) null else r?.hole ?: hole,gap=if(field==Field.GAP) null else r?.gap ?: gap)
 }
}
class LocalStore(context:Context) {
 private val prefs=context.getSharedPreferences("bolt-circle",Context.MODE_PRIVATE)
 fun load():Setup=runCatching {
  if(!prefs.contains("saved")) return Setup()
  fun read(k:String)=prefs.getString(k,null)?.toDouble()?.also{require(it.isFinite() && it>=0 && it<=BoltCircle.MAX_LENGTH)}
  Setup(prefs.getString("count",null)?.toInt()?.also{require(it in 2..360)},read("bc"),read("hole"),read("gap"),prefs.getString("angle","0")!!.toDouble().also{require(it.isFinite() && kotlin.math.abs(it)<=360000)},LengthUnit.valueOf(prefs.getString("unit","INCH")!!))
 }.getOrDefault(Setup())
 fun save(s:Setup) {
  val edit=prefs.edit().putBoolean("saved",true).putString("count",s.count?.toString())
  mapOf("bc" to s.bc,"hole" to s.hole,"gap" to s.gap,"angle" to s.firstAngle).forEach{(k,v)->edit.putString(k,v?.toString())}
  edit.putString("unit",s.unit.name).apply()
 }
}
