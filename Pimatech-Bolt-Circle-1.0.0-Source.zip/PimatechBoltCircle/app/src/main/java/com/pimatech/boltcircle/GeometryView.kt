package com.pimatech.boltcircle
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import com.pimatech.boltcircle.engine.*
import kotlin.math.*
private data class Plot(val center:Offset,val radius:Float,val scale:Float,val holeRadius:Float)
private fun plot(size:Size,r:Solution,margin:Float):Plot {
 val d=r.hole ?: 0.0
 val extent=(r.bc!!+d).toFloat()
 val available=(min(size.width,size.height)-margin).coerceAtLeast(1f)
 val scale=available/extent
 return Plot(Offset(size.width/2,size.height/2),r.bc!!.toFloat()/2*scale,scale,d.toFloat()/2*scale)
}
private fun screen(p:Point,plot:Plot)=plot.center+Offset(p.x.toFloat()*plot.scale,-p.y.toFloat()*plot.scale)
@Composable fun GeometryView(s:Setup,r:Solution?,modifier:Modifier=Modifier,onHole:(Int)->Unit){
 Canvas(modifier.testTag("boltDiagram").semantics {
  contentDescription=if(r?.hasPattern==true) "Bolt circle with ${r.count} holes. Zero degrees right, 90 degrees up. Tap a hole for X/Y from BC center. Inside span joins holes 1 and 2." else "Bolt-circle drawing needs hole count and bolt-circle diameter."
  if(r?.hasPattern==true) customActions=(0 until r.count!!).map{i->CustomAccessibilityAction("Hole ${i+1} coordinates"){onHole(i);true}}
 }.pointerInput(r){detectTapGestures{tap->
  if(r?.hasPattern==true){
   val p=plot(Size(size.width.toFloat(),size.height.toFloat()),r,50.dp.toPx())
   val nearest=(0 until r.count!!).minByOrNull{(screen(r.point(it),p)-tap).getDistance()}
   if(nearest!=null && (screen(r.point(nearest),p)-tap).getDistance()<=max(p.holeRadius,22.dp.toPx())) onHole(nearest)
  }
 }}){
  val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{textAlign=android.graphics.Paint.Align.CENTER;textSize=11.dp.toPx();typeface=android.graphics.Typeface.DEFAULT_BOLD}
  fun text(t:String,x:Float,y:Float,c:Color){paint.color=c.toArgb();drawContext.canvas.nativeCanvas.drawText(t,x,y,paint)}
  if(r?.hasPattern!=true){text(if(r==null) "CHECK SUPPLIED VALUES" else "SUPPLY COUNT + BC Ø TO DRAW",size.width/2,size.height/2,Muted);return@Canvas}
  val p=plot(size,r,50.dp.toPx());val center=p.center
  val dash=PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(),4.dp.toPx()))
  drawLine(Muted.copy(alpha=.5f),Offset(10f,center.y),Offset(size.width-10f,center.y),1.dp.toPx(),pathEffect=dash)
  drawLine(Muted.copy(alpha=.5f),Offset(center.x,10f),Offset(center.x,size.height-10f),1.dp.toPx(),pathEffect=dash)
  drawCircle(if(s.bc!=null) Warn else Good,p.radius,center,style=Stroke(1.5.dp.toPx(),pathEffect=dash))
  drawLine(Cyan,center-Offset(6.dp.toPx(),0f),center+Offset(6.dp.toPx(),0f),1.dp.toPx())
  drawLine(Cyan,center-Offset(0f,6.dp.toPx()),center+Offset(0f,6.dp.toPx()),1.dp.toPx())
  text("+X / 0°",size.width-28.dp.toPx(),center.y-5.dp.toPx(),Muted)
  text("+Y / 90°",center.x,12.dp.toPx(),Muted)
  val holeColor=if(s.hole!=null) Warn else Good
  for(i in 0 until r.count!!){
   val pos=screen(r.point(i),p)
   if(r.hole!=null){drawCircle(holeColor.copy(alpha=.1f),p.holeRadius,pos);drawCircle(holeColor,p.holeRadius,pos,style=Stroke(1.6.dp.toPx()))}
   else drawCircle(Cyan.copy(alpha=.3f),4.dp.toPx(),pos)
   drawCircle(Cyan,2.dp.toPx(),pos)
   if(r.count!!<=24){
    val direction=pos-center;val len=direction.getDistance().coerceAtLeast(1f)
    val label=pos+direction/len*(p.holeRadius+10.dp.toPx())
    text((i+1).toString(),label.x.coerceIn(8.dp.toPx(),size.width-8.dp.toPx()),(label.y+4.dp.toPx()).coerceIn(12.dp.toPx(),size.height-3.dp.toPx()),Cyan)
   }
  }
  if(r.hole!=null && r.gap!=null){
   val a=screen(r.point(0),p);val b=screen(r.point(1),p)
   val delta=b-a;val length=delta.getDistance().coerceAtLeast(1e-20f);val direction=delta/length
   val start=a+direction*p.holeRadius;val end=b-direction*p.holeRadius
   val color=if(s.gap!=null) Warn else Good
   drawLine(color,start,end,2.2.dp.toPx())
   val normal=Offset(-direction.y,direction.x)*4.dp.toPx()
   drawLine(color,start-normal,start+normal,1.5.dp.toPx());drawLine(color,end-normal,end+normal,1.5.dp.toPx())
  }
 }
}
