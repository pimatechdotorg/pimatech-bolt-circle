package com.pimatech.boltcircle
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.pimatech.boltcircle.engine.*
import kotlin.math.*
import java.util.Locale
fun measure(value:Double?,u:LengthUnit,signed:Boolean=false):String {
 if(value==null) return "—"
 val v=u.display(value);val resolution=10.0.pow(-u.decimals)
 if(v!=0.0 && abs(v)<resolution/2) return (if(v<0) "−" else if(signed) "+" else "")+"<"+String.format(Locale.US,"%.${u.decimals}f",resolution)+" "+u.label
 return (if(signed && v>0) "+" else "")+String.format(Locale.US,"%.${u.decimals}f %s",if(v==0.0) 0.0 else v,u.label)
}
class MainActivity:ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  val store=LocalStore(this)
  setContent{MaterialTheme(colorScheme=darkColorScheme(primary=Cyan,background=Ink,surface=Panel,onSurface=Color.White,onBackground=Color.White,error=Bad,secondary=Good)){
   var state by remember{mutableStateOf(store.load())}
   Calculator(state){state=it;store.save(it)}
  }}
 }
}
@Composable fun BoltValue(label:String,value:String,supplied:Boolean,known:Boolean,modifier:Modifier,onClick:()->Unit) {
 val color=if(!known) Muted else if(supplied) Warn else Good
 Surface(onClick=onClick,color=Panel,shape=RoundedCornerShape(8.dp),modifier=modifier.heightIn(min=54.dp)){
  Column(Modifier.padding(horizontal=10.dp,vertical=5.dp)){
   Text(label+" · "+if(!known) "NEEDED" else if(supplied) "INPUT" else "CALCULATED",fontSize=9.sp,lineHeight=12.sp,color=color)
   Text(value,color=color,fontSize=19.sp,lineHeight=24.sp,fontWeight=FontWeight.SemiBold)
  }
 }
}
@Composable fun Calculator(s:Setup,change:(Setup)->Unit) {
 var popup by remember{mutableStateOf<String?>(null)}
 var entry by remember{mutableStateOf<Entry?>(null)}
 var selected by remember{mutableIntStateOf(0)}
 val result=runCatching{s.solution()};val r=result.getOrNull();val u=s.unit
 fun editLength(field:Field,current:Double?) {
  entry=Entry(field.label,current?.let{u.display(it)},u.label+" · Clear + Save to make unknown",nullable=true,validate={
   if(it.isFinite() && (if(field==Field.GAP) it>=0 else it>0) && u.canonical(it)<=BoltCircle.MAX_LENGTH) null else if(field==Field.GAP) "Use zero or greater, within 1,000,000 mm." else "Use a positive dimension, within 1,000,000 mm."
  }){v->val mm=v?.let(u::canonical);change(when(field){Field.BC->s.copy(bc=mm);Field.HOLE->s.copy(hole=mm);else->s.copy(gap=mm)})}
 }
 fun openHole(index:Int){selected=index;popup="hole"}
 Surface(color=Ink,modifier=Modifier.fillMaxSize()) {
  BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
   val fallback=maxHeight<650.dp || androidx.compose.ui.platform.LocalDensity.current.fontScale>1.2f
   Column(Modifier.fillMaxSize().then(if(fallback) Modifier.verticalScroll(rememberScrollState()) else Modifier).padding(horizontal=12.dp,vertical=6.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     Column(Modifier.weight(1f)){Text("PIMATECH",color=Cyan,fontSize=11.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp);Text("BOLT CIRCLE RESOLVER",fontSize=19.sp,fontWeight=FontWeight.Bold)}
     TextButton(onClick={popup="settings"}){Text(u.label.uppercase(),fontWeight=FontWeight.Bold)}
    }
    InputRow {Text("● INPUT",color=Warn,fontSize=11.sp);Text("● CALCULATED",color=Good,fontSize=11.sp);Text("0° RIGHT · CCW +",color=Muted,fontSize=10.sp)}
    Surface(color=Panel,shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth().then(if(fallback) Modifier.height(240.dp) else Modifier.weight(1f))){
     Column(Modifier.padding(8.dp)){
      Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("TAP A HOLE FOR X / Y",fontSize=10.sp,color=Muted,modifier=Modifier.weight(1f));TextButton(onClick={popup="geometry"},contentPadding=PaddingValues(4.dp),modifier=Modifier.height(30.dp)){Text("Expand",fontSize=11.sp)}}
      GeometryView(s,r,Modifier.fillMaxWidth().weight(1f),::openHole)
      Text("INSIDE SPAN: "+measure(s.gap ?: r?.gap,u)+" · "+if(s.gap!=null) "INPUT" else if(r?.gap!=null) "CALCULATED" else "NEEDED",color=if(s.gap!=null) Warn else Good,fontSize=11.sp,modifier=Modifier.fillMaxWidth(),textAlign=androidx.compose.ui.text.style.TextAlign.Center)
     }
    }
    InputRow {
     BoltValue("Hole count",(s.count ?: r?.count)?.let{"$it holes"} ?: "—",s.count!=null,(s.count ?: r?.count)!=null,Modifier.weight(1f)){
      entry=Entry("Hole count",(s.count ?: r?.count)?.toDouble(),"2–360 · whole holes · Clear to calculate",nullable=true,validate={if(it in 2.0..360.0 && it%1==0.0) null else "Enter a whole count from 2 through 360."}){change(s.copy(count=it?.toInt()))}
     }
     BoltValue("First-hole angle",String.format(Locale.US,"%.4f°",s.firstAngle),true,true,Modifier.weight(1f)){
      entry=Entry("First-hole angle",s.firstAngle,"0° at +X / 3 o'clock · CCW positive",signed=true,validate={if(abs(it)<=360000) null else "Use an angle within ±360,000°."}){change(s.copy(firstAngle=BoltCircle.normalize(it!!)))}
     }
    }
    InputRow {
     BoltValue("Bolt circle Ø",measure(s.bc ?: r?.bc,u),s.bc!=null,(s.bc ?: r?.bc)!=null,Modifier.weight(1f)){editLength(Field.BC,s.bc ?: r?.bc)}
     BoltValue("Hole Ø",measure(s.hole ?: r?.hole,u),s.hole!=null,(s.hole ?: r?.hole)!=null,Modifier.weight(1f)){editLength(Field.HOLE,s.hole ?: r?.hole)}
    }
    BoltValue("Inside span · adjacent edges",measure(s.gap ?: r?.gap,u),s.gap!=null,(s.gap ?: r?.gap)!=null,Modifier.fillMaxWidth()){editLength(Field.GAP,s.gap ?: r?.gap)}
    Surface(color=Good.copy(alpha=.08f),shape=RoundedCornerShape(10.dp),modifier=Modifier.fillMaxWidth()){
     InputRow {
      ResultCell("ADJACENT CENTERS",measure(r?.chord,u),Good,Modifier.weight(1f))
      ResultCell("ANGULAR SPACING",r?.spacing?.let{String.format(Locale.US,"%.6f°",it)} ?: "—",Good,Modifier.weight(1f))
     }
    }
    Text(if(result.isFailure) result.exceptionOrNull()?.message ?: "Check inputs." else if(r?.count==null || r.bc==null || r.hole==null || r.gap==null) "Supply any 3 of: hole count, BC Ø, hole Ø, inside span. Angle sets orientation only." else "Span is the clear gap between adjacent hole edges. Tap a value to edit or clear.",color=if(result.isFailure) Bad else Muted,fontSize=11.sp,lineHeight=13.sp)
    InputRow {
     ActionButton("Solve / inputs",Modifier.weight(1f)){popup="inputs"}
     OutlinedButton(onClick={popup="coordinates"},enabled=r?.hasPattern==true,modifier=Modifier.weight(1f).heightIn(min=48.dp),shape=RoundedCornerShape(8.dp),contentPadding=PaddingValues(5.dp)){Text("Coordinates",fontSize=10.sp)}
     ActionButton("Help",Modifier.weight(1f)){popup="help"}
    }
    Attribution()
   }
  }
 }
 when(popup){
  "geometry"->ShopDialog("Bolt-circle drawing",{popup=null}){
   GeometryView(s,r,Modifier.fillMaxWidth().height(320.dp),::openHole)
   Text("Tap a hole for its X/Y coordinates. X positive right; Y positive up. Zero is at 3 o'clock, angles and numbering increase counterclockwise. Span joins the nearest edges of Holes 1 and 2 along their centerline.",color=Muted)
   Text("Hole centers and diameters are drawn to scale when known. Center markers are illustrative if hole Ø is unknown. Dense patterns can also be selected in Coordinates.",color=Muted,fontSize=12.sp)
  }
  "hole"->if(r?.hasPattern==true){
   val count=r.count!!
   val p=r.point(selected.coerceIn(0,count-1))
   ShopDialog("Hole ${p.number} · X / Y",{popup=null}){
    Text("FROM BOLT-CIRCLE CENTER",color=Muted,fontSize=11.sp)
    Text("X  "+measure(p.x,u,true),color=Good,fontSize=26.sp,fontWeight=FontWeight.Bold)
    Text("Y  "+measure(p.y,u,true),color=Good,fontSize=26.sp,fontWeight=FontWeight.Bold)
    Text(String.format(Locale.US,"Angle: %.6f° · CCW from +X",p.angle),color=Cyan)
    Text("Radius: "+measure(r.bc!!/2,u),color=Muted)
    InputRow {
     OutlinedButton(onClick={selected=(selected+count-1)%count},modifier=Modifier.weight(1f)){Text("Previous")}
     OutlinedButton(onClick={selected=(selected+1)%count},modifier=Modifier.weight(1f)){Text("Next")}
    }
    Button(onClick={popup="coordinates"},modifier=Modifier.fillMaxWidth()){Text("All coordinates")}
   }
  }
  "coordinates"->if(r?.hasPattern==true) CoordinatesDialog(r,u,{popup=null},::openHole)
  "inputs"->ShopDialog("Solve / inputs",{popup=null}){
   Text("Choose the value to calculate. The other available values are kept as supplied inputs.")
   Field.entries.forEach{f->OutlinedButton(onClick={change(s.unknown(f));popup=null},modifier=Modifier.fillMaxWidth()){Text("Calculate "+f.label.lowercase())}}
   Text("Or tap any field: Clear + Save makes it unknown. Calculated values are never silently treated as supplied measurements. Four supplied values must agree; clear one to resolve a conflict.",color=Muted)
   OutlinedButton(onClick={change(Setup(count=null,bc=null,hole=null,gap=null,firstAngle=s.firstAngle,unit=u));popup=null},modifier=Modifier.fillMaxWidth()){Text("Clear all dimensions")}
   Button(onClick={change(Setup(unit=u));popup=null},modifier=Modifier.fillMaxWidth()){Text("Restore 6-hole example")}
  }
  "settings"->ShopDialog("Settings",{popup=null}){
   Text("Display units · physical dimensions are preserved")
   InputRow {LengthUnit.entries.forEach{unit->OutlinedButton(onClick={change(s.copy(unit=unit))},modifier=Modifier.weight(1f)){Text((if(u==unit) "✓ " else "")+unit.label)}}}
   Text("Equal spacing around a full 360° circle. Hole count: 2–360. First-hole angle defaults to 0° and is independent of span; lengths cannot determine pattern rotation.")
   Text("Inch display: 6 decimals · metric: 5. Calculations use full stored precision. Display resolution does not imply measurement accuracy. Inputs and settings save locally. No network access, ads or analytics.",color=Muted)
   Text("Version 1.0.0 · Native Android · MIT open source",color=Muted,fontSize=12.sp)
  }
  "help"->ShopDialog("Operator & engineering",{popup=null}){
   Text("Supply any three of: hole count N, bolt-circle diameter B, common hole diameter d, and inside edge-to-edge span S. Unknown values appear green when determined; supplied values are amber. Solve / inputs chooses which one to calculate without manually clearing it.")
   Text("Span is the CLEAR INSIDE GAP between adjacent holes, measured along their line of centers. It is not the overall width across the pattern or an outside measurement. Enter a nominal inside gap or an inside-gap output from Hole Distance Resolver; no automatic app-to-app transfer is provided.")
   Text("C = S + d = B × sin(180° / N)\nB = (S + d) / sin(180° / N)\nS = B × sin(180° / N) − d\nd = B × sin(180° / N) − S\nN = 180° / asin((S + d) / B)",color=Cyan)
   Text("A calculated N must be a whole number from 2 through 360. A fractional count is rejected, never silently rounded to a pattern. A known count plus B can already determine spacing and coordinates even if d and S are still missing.")
   Text("Hole i: θ = first angle + (i − 1) × 360°/N\nX = (B/2) cos θ\nY = (B/2) sin θ\n0° at 3 o'clock; 90° at 12; CCW positive.",color=Cyan)
   Text("Assumes equally spaced, equal-size round holes on a complete circle, with parallel axes. Span touches the nearest walls of neighboring holes in a common measurement plane. Tangency (zero inside gap) is allowed; overlapping holes are rejected. Off-center chords, skewed jaws, chamfers and out-of-round holes affect caliper results.")
   Text("No GD&T true-position assessment, calibration, temperature or uncertainty compensation. If all four values are supplied, only tiny numerical differences are accepted; this is an equation-consistency check, not an inspection tolerance. Clear an input to solve from the others.",color=Muted)
  }
 }
 entry?.let{e->NumericDialog(e,{entry=null}){e.commit(it);entry=null}}
}
@Composable fun CoordinatesDialog(r:Solution,u:LengthUnit,onDismiss:()->Unit,onHole:(Int)->Unit){
 Dialog(onDismissRequest=onDismiss){Surface(color=Panel,shape=RoundedCornerShape(16.dp)){
  Column(Modifier.fillMaxWidth().heightIn(max=680.dp).padding(16.dp)){
   Text("Hole coordinates",color=Cyan,fontSize=21.sp,fontWeight=FontWeight.Bold)
   Text("From BC center · X right / Y up\n0° right · CCW positive · tap a row",color=Muted,fontSize=11.sp)
   LazyColumn(Modifier.weight(1f,fill=false).padding(top=10.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
    items((0 until r.count!!).toList(),key={it}){i->val p=r.point(i)
     Surface(onClick={onHole(i)},color=Ink,shape=RoundedCornerShape(8.dp),modifier=Modifier.fillMaxWidth()){
      Column(Modifier.padding(8.dp)){
       Text("Hole ${p.number} · "+String.format(Locale.US,"%.4f°",p.angle),color=Cyan,fontSize=12.sp)
       Text("X "+measure(p.x,u,true)+"\nY "+measure(p.y,u,true),color=Good,fontSize=14.sp)
      }
     }
    }
   }
   TextButton(onClick=onDismiss,modifier=Modifier.align(Alignment.End)){Text("Close")}
   Attribution()
  }
 }}
}
