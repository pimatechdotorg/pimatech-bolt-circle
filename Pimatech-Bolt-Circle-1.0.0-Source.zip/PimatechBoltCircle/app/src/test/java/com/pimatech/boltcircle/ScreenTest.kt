package com.pimatech.boltcircle
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import kotlin.math.min
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],qualifiers="w411dp-h731dp-port")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ScreenTest {
 @get:Rule val rule=createAndroidComposeRule<MainActivity>()
 private fun shot(name:String,dialog:Boolean=false){rule.runOnIdle{
  val view=if(dialog) org.robolectric.shadows.ShadowDialog.getLatestDialog().window!!.decorView else rule.activity.window.decorView
  val bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888);view.draw(Canvas(bitmap))
  val file=File("build/ui-proof/$name.png");file.parentFile!!.mkdirs();file.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
 }}
 @Test fun exampleTapHoleAndCoordinates(){
  rule.onNodeWithText("5.000000 in").assertIsDisplayed()
  rule.onNodeWithText("Bolt circle Ø · CALCULATED").assertIsDisplayed()
  rule.onNodeWithText("Inside span · adjacent edges · INPUT").assertIsDisplayed()
  rule.onNodeWithText("Proudly made and released open source by PimaTech.org").assertIsDisplayed()
  shot("default")
  rule.onNodeWithTag("boltDiagram").performTouchInput{click(Offset(width/2f+(min(width,height)-50f)*5f/11f,height/2f))}
  rule.onNodeWithText("Hole 1 · X / Y").assertIsDisplayed()
  rule.onNodeWithText("X  +2.500000 in").assertIsDisplayed();rule.onNodeWithText("Y  0.000000 in").assertIsDisplayed()
  shot("hole-popup",true)
  rule.onNodeWithText("Next").performClick()
  rule.onNodeWithText("X  +1.250000 in").assertIsDisplayed();rule.onNodeWithText("Y  +2.165064 in").assertIsDisplayed()
  rule.onNodeWithText("All coordinates").performClick()
  rule.onNodeWithText("Hole 1 · 0.0000°").assertIsDisplayed()
  shot("coordinates",true)
 }
 @Test fun chooseEachUnknownAndPreserveState(){
  for(label in listOf("Calculate inside span","Calculate hole diameter","Calculate hole count","Calculate bolt-circle diameter")){
   rule.onNodeWithText("Solve / inputs").performClick();rule.onNodeWithText(label).performClick()
   rule.onNodeWithText("5.000000 in").assertIsDisplayed()
  }
  rule.activityRule.scenario.recreate();rule.onNodeWithText("Bolt circle Ø · CALCULATED").assertIsDisplayed()
  rule.onNodeWithText("Solve / inputs").performClick();rule.onNodeWithText("Calculate inside span").performClick()
  rule.onNodeWithText("Inside span · adjacent edges · CALCULATED").assertIsDisplayed()
  shot("calculated-span")
 }
 @Test fun clearPartialConflictAndCountInference(){
  rule.onNodeWithText("Solve / inputs").performClick();rule.onNodeWithText("Calculate hole count").performClick()
  rule.onNodeWithText("Hole count · CALCULATED").assertIsDisplayed()
  rule.onNodeWithText("Hole count · CALCULATED").performClick();rule.onNodeWithText("5").performClick();rule.onNodeWithText("Save").performClick()
  rule.onNodeWithText("Supplied values disagree. Clear one value, or use Solve / inputs to choose the unknown.").assertIsDisplayed()
  shot("conflict")
  rule.onNodeWithText("Hole count · INPUT").performClick();rule.onNodeWithText("Clear").performClick();rule.onNodeWithText("Save").performClick()
  rule.onNodeWithText("Hole count · CALCULATED").assertIsDisplayed()
  rule.onNodeWithText("Solve / inputs").performClick();rule.onNodeWithText("Clear all dimensions").performScrollTo().performClick()
  rule.onNodeWithText("Hole count · NEEDED").assertIsDisplayed()
  rule.onNodeWithText("SUPPLY COUNT + BC Ø TO DRAW").assertDoesNotExist() // Drawing text is canvas; accessible description is checked below.
  rule.onNodeWithContentDescription("Bolt-circle drawing needs hole count and bolt-circle diameter.").assertIsDisplayed()
 }
 @Test fun unitsAndFirstHoleAngle(){
  rule.onNodeWithText("First-hole angle · INPUT").performClick();listOf("9","0").forEach{rule.onNodeWithText(it).performClick()};rule.onNodeWithText("Save").performClick()
  rule.onNodeWithText("Coordinates").performClick();rule.onNodeWithText("Hole 1 · 90.0000°").performClick()
  rule.onNodeWithText("X  0.000000 in").assertIsDisplayed();rule.onNodeWithText("Y  +2.500000 in").assertIsDisplayed()
  rule.onNodeWithText("Close").performClick()
  rule.onNodeWithText("IN").performClick();rule.onNodeWithText("mm").performClick();rule.onNodeWithText("Close").performClick()
  rule.onNodeWithText("127.00000 mm").assertIsDisplayed()
  rule.activityRule.scenario.recreate();rule.onNodeWithText("90.0000°").assertIsDisplayed();rule.onNodeWithText("127.00000 mm").assertIsDisplayed()
 }
 @Test @Config(qualifiers="w320dp-h480dp-port") fun compactViewport(){
  rule.onNodeWithText("Proudly made and released open source by PimaTech.org").performScrollTo().assertIsDisplayed()
  rule.onNodeWithText("Coordinates").performScrollTo().performClick();rule.onNodeWithText("Hole 1 · 0.0000°").assertIsDisplayed()
  rule.onNodeWithText("Close").performClick();rule.onNodeWithText("Hole count · INPUT").performScrollTo().performClick()
  rule.onNodeWithText("Cancel").performScrollTo().performClick()
 }
}
