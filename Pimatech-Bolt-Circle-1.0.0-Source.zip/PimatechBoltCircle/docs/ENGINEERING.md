# Engineering notes

The engine solves one relation in four unknowns: S + d = B sin(π/N), with N restricted to integer values 2–360. The app records only supplied inputs. A solution is derived afresh whenever those inputs change, so calculated outputs never become hidden constraints. A supplied count plus B supports a partial solution (spacing, chord and coordinates) without assuming a missing diameter or gap.

If exactly one quantity is unknown, it is solved algebraically. Solving N uses π/asin((S+d)/B); the result must be within 1e-6 holes of an integer. This permits floating-point error, not arbitrary measurement rounding. Enter the known count when measured dimensions do not yield a whole number. Ratios up to 1+1e-12 permit only numerical noise at the two-hole boundary.

If all four quantities are supplied, the residual |(S+d) − B sin(π/N)| must be at most max(1e-9 mm, |chord| × 1e-10). This is a numerical consistency test, not an inspection tolerance or measurement uncertainty. Conflicts are explicit and calculated outputs are hidden. Inputs are never overwritten to resolve a conflict. Solve / inputs or Clear + Save removes a constraint.

Hole diameter and BC diameter must be positive; inside gap may be zero. All supplied and calculated lengths are limited to 1,000,000 mm. First-hole angle is accepted within ±360,000° and normalized to [0,360). Normalization does not change the pattern. Hole count does not use fractional rounding in the keypad.

Lengths are stored as full-precision Double millimeters. Inch conversion uses 25.4. Unit switches change presentation only; repeated switching does not rewrite stored lengths. Trigonometry uses radians internally. The final display rounds to six places in inches, five in mm. Nonzero sub-resolution dimensions use a less-than-resolution notation. Very small unit-vector components at cardinal angles are set to zero before scaling, avoiding misleading signed numerical noise.

Coordinates use the standard Cartesian convention: +X right, +Y up, 0° at +X, positive angles counterclockwise. Android screen Y is inverted only when rendering. All coordinates and angles are referenced to BC center and Hole 1 orientation, not to machine/work offsets or drawing datums. Hole numbering increments by 360°/N.

The drawing uses a common X/Y scale and includes the full hole extents. Touches select the nearest hole center within its drawn radius or a 22dp minimum reach. Nearest-center selection resolves dense touch areas deterministically. Each hole also has a named accessibility action; the separate lazy coordinate list permits precise selection in dense patterns. Hole markers are illustrative when no diameter is supplied. Span contacts are nearest-edge points along the first adjacent center chord.

Settings and supplied values persist in local SharedPreferences, including unknown/null fields. Corrupt local values fall back to the example; inconsistent but well-formed input combinations remain editable and are flagged by the engine. No network, external service or analytics is used.
