# Validation — 1.0.0 development preview

Validated 2026-10-27 using JDK 17, Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21 and Android SDK / Build Tools 35.

- Final complete build: `:engine:test :app:assembleDebug :app:lintDebug :app:testDebugUnitTest`, BUILD SUCCESSFUL in 56s.
- Eight engine test groups passed, no failures/errors. Covered all four unknowns, the owner's six-hole example, partial solutions, cardinal coordinates, counterclockwise numbering, negative-angle normalization, tangent/two-hole boundaries, 360-hole limits, fractional-count rejection, conflicting inputs, range validation, overlap, and unit scaling.
- 500 independent Cartesian-coordinate oracle patterns validated chord-based geometry, every unknown and rotated X/Y coordinates. The oracle obtains chord length from the distance between two Cartesian points, rather than repeating the span formula.
- Five host-side Android UI tests passed, no failures/errors, under Robolectric 4.14.1 / API 28 / native graphics. Verified an actual tap on Hole 1 opening its X/Y popup, Next navigation to Hole 2, the scrolling coordinate list, changing each unknown, computed/supplied labels, clear-to-unknown behavior, conflicting-input handling, inch/mm switching, first-hole rotation, persistence across Activity recreation, and 320 × 480 dp accessibility of controls.
- Native 411 × 731 dp renders inspected: default (supplied span), calculated span, hole popup, coordinate list, and conflicting inputs. Both color states and all standard-screen controls were visible; native proof images are included.
- Android lint: 0 errors, 0 warnings.
- Manifest verified: separate package `com.pimatech.boltcircle`, version 1.0.0 / code 1, min API 26 (Android 8), target API 35. No Internet permission; only AndroidX app-specific signature receiver permission.
- APK v2 signature verified. Development certificate SHA256: `f3e3d3473d8a7a94419b1eba8eaca0693ee09b612f7659e959feeb8db2d446cb`.

APK SHA256: `fa2b68def70ed6fe338227754b5bd14f718adc699e978f80aefe5fe81defb40e`.

The APK has not yet been installed or accepted by the owner, nor validated by the developer against physical measured parts. It is a development preview for owner review. Automated numerical checks do not establish instrument accuracy or certify an inspection procedure.
