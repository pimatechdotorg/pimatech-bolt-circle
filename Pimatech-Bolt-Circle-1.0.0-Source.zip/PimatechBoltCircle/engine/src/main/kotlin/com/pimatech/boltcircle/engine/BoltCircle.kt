package com.pimatech.boltcircle.engine
import kotlin.math.*
import java.util.Locale

enum class LengthUnit(val label:String,val decimals:Int) {
 INCH("in",6), MM("mm",5);
 fun canonical(value:Double)=if(this==INCH) value*25.4 else value
 fun display(mm:Double)=if(this==INCH) mm/25.4 else mm
}
enum class Field(val label:String) { COUNT("Hole count"), BC("Bolt-circle diameter"), HOLE("Hole diameter"), GAP("Inside span") }
data class Inputs(val count:Int?=null,val bc:Double?=null,val hole:Double?=null,val gap:Double?=null,val firstAngle:Double=0.0)
data class Point(val number:Int,val angle:Double,val x:Double,val y:Double)
data class Solution(val count:Int?,val bc:Double?,val hole:Double?,val gap:Double?,val chord:Double?,val spacing:Double?,val firstAngle:Double) {
 fun point(index:Int):Point {
  require(count!=null && bc!=null && index in 0 until count)
  val angle=BoltCircle.normalize(firstAngle+index*360.0/count)
  // Exact cardinal handling prevents distracting signed near-zero coordinates.
  val radians=Math.toRadians(angle)
  fun clean(v:Double)=if(abs(v)<1e-14) 0.0 else v
  return Point(index+1,angle,bc/2*clean(cos(radians)),bc/2*clean(sin(radians)))
 }
 val hasPattern:Boolean get()=count!=null && bc!=null
}
object BoltCircle {
 const val MAX_LENGTH=1000000.0
 fun normalize(degrees:Double):Double {val n=((degrees%360)+360)%360;return if(n==0.0) 0.0 else n}
 private fun positive(v:Double?,name:String) {require(v==null || (v.isFinite() && v>0 && v<=MAX_LENGTH)){"$name must be greater than zero, up to 1,000,000 mm."}}
 fun solve(i:Inputs):Solution {
  require(i.count==null || i.count in 2..360){"Hole count must be a whole number from 2 through 360."}
  positive(i.bc,"Bolt-circle diameter");positive(i.hole,"Hole diameter")
  require(i.gap==null || (i.gap.isFinite() && i.gap>=0 && i.gap<=MAX_LENGTH)){"Inside span must be zero or greater, up to 1,000,000 mm."}
  require(i.firstAngle.isFinite() && abs(i.firstAngle)<=360000){"First-hole angle must be finite and within ±360,000°."}
  var n=i.count;var b=i.bc;var d=i.hole;var g=i.gap
  if(n==null && b!=null && d!=null && g!=null) {
   val ratio=(g+d)/b
   require(ratio>0 && ratio<=1.0+1e-12){"Span plus hole diameter exceeds the bolt-circle diameter. No equally spaced pattern fits."}
   val raw=PI/asin(ratio.coerceAtMost(1.0))
   require(raw.isFinite() && raw>=2-1e-8 && raw<=360+1e-8){"These dimensions imply a hole count outside 2–360."}
   val candidate=raw.roundToInt()
   require(abs(raw-candidate)<=1e-6){"Dimensions do not imply a whole-number hole count (${String.format(Locale.US,"%.6f",raw)}). Enter the known count or check the span."}
   n=candidate
  }
  if(n!=null) {
   val factor=sin(PI/n)
   if(b==null && d!=null && g!=null) b=(g+d)/factor
   if(b!=null) {
    positive(b,"Calculated bolt-circle diameter")
    val chord=b*factor
    if(d==null && g!=null) d=chord-g
    if(g==null && d!=null) g=chord-d
    positive(d,"Calculated hole diameter")
    // Permit only binary floating-point noise at the zero-gap boundary.
    val tolerance=max(1e-9,abs(chord)*1e-10)
    if(g!=null && g<0 && g>=-tolerance && i.gap==null) g=0.0
    require(g==null || (g>=0 && g<=MAX_LENGTH)){"Hole diameters overlap, or the calculated inside span is outside range."}
    if(d!=null && g!=null) require(abs((g+d)-chord)<=tolerance){"Supplied values disagree. Clear one value, or use Solve / inputs to choose the unknown."}
    return Solution(n,b,d,g,chord,360.0/n,normalize(i.firstAngle))
   }
  }
  return Solution(n,b,d,g,null,n?.let{360.0/it},normalize(i.firstAngle))
 }
}
