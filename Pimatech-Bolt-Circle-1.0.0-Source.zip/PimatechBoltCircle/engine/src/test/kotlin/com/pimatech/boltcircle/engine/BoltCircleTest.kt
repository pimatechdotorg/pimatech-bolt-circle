package com.pimatech.boltcircle.engine
import org.junit.Test
import org.junit.Assert.*
import kotlin.math.*
import kotlin.random.Random
class BoltCircleTest {
 private fun close(expected:Double,actual:Double?)=assertEquals(expected,actual!!,max(1e-8,abs(expected)*1e-9))
 @Test fun shopExampleAndEveryUnknown(){
  val s=BoltCircle.solve(Inputs(count=6,hole=.5,gap=2.0));close(5.0,s.bc);close(2.5,s.chord);close(60.0,s.spacing)
  close(2.0,BoltCircle.solve(Inputs(count=6,bc=5.0,hole=.5)).gap)
  close(.5,BoltCircle.solve(Inputs(count=6,bc=5.0,gap=2.0)).hole)
  assertEquals(6,BoltCircle.solve(Inputs(bc=5.0,hole=.5,gap=2.0)).count)
 }
 @Test fun cardinalOrientationAndNumbering(){
  val s=BoltCircle.solve(Inputs(count=4,bc=10.0,firstAngle=0.0))
  close(5.0,s.point(0).x);assertEquals(0.0,s.point(0).y,0.0)
  assertEquals(0.0,s.point(1).x,0.0);close(5.0,s.point(1).y)
  close(-5.0,s.point(2).x);assertEquals(0.0,s.point(2).y,0.0)
  close(-5.0,s.point(3).y);assertEquals(0.0,s.point(3).x,0.0)
  val rotated=BoltCircle.solve(Inputs(count=4,bc=10.0,firstAngle=-90.0))
  close(270.0,rotated.point(0).angle);close(-5.0,rotated.point(0).y);close(5.0,rotated.point(1).x)
 }
 @Test fun partialSolutionsNeverInventData(){
  val empty=BoltCircle.solve(Inputs());assertNull(empty.count);assertNull(empty.bc);assertNull(empty.chord);assertNull(empty.spacing);assertFalse(empty.hasPattern)
  val nOnly=BoltCircle.solve(Inputs(count=6));close(60.0,nOnly.spacing);assertNull(nOnly.bc)
  val pair=BoltCircle.solve(Inputs(count=6,bc=5.0));assertTrue(pair.hasPattern);close(2.5,pair.chord);assertNull(pair.hole);assertNull(pair.gap)
  val two=BoltCircle.solve(Inputs(hole=.5,gap=2.0));assertNull(two.bc);assertNull(two.count)
 }
 @Test fun tangentAndTwoHoleLimits(){
  val tangent=BoltCircle.solve(Inputs(count=2,bc=1.0,hole=1.0));close(0.0,tangent.gap);close(180.0,tangent.spacing)
  assertEquals(2,BoltCircle.solve(Inputs(bc=1.0,hole=1.0,gap=0.0)).count)
  assertEquals(360,BoltCircle.solve(Inputs(bc=100.0,hole=.1,gap=100*sin(PI/360)-.1)).count)
 }
 @Test fun fractionalCountsAndConflictsAreRejected(){
  assertThrows(IllegalArgumentException::class.java){BoltCircle.solve(Inputs(bc=5.0,hole=.5,gap=2.1))}
  assertThrows(IllegalArgumentException::class.java){BoltCircle.solve(Inputs(count=6,bc=5.0,hole=.5,gap=2.1))}
  assertThrows(IllegalArgumentException::class.java){BoltCircle.solve(Inputs(bc=2.0,hole=.5,gap=2.0))}
  close(2.0,BoltCircle.solve(Inputs(count=6,bc=5.0,hole=.5,gap=2.0)).gap)
 }
 @Test fun invalidAndOverlappingGeometry(){
  listOf(Inputs(count=1),Inputs(count=361),Inputs(bc=0.0),Inputs(hole=-1.0),Inputs(gap=-1.0),Inputs(bc=Double.NaN),Inputs(firstAngle=Double.POSITIVE_INFINITY),Inputs(firstAngle=360001.0),Inputs(bc=1000001.0),Inputs(count=6,bc=1.0,hole=1.0),Inputs(count=6,bc=1.0,gap=1.0),Inputs(count=360,hole=10000.0,gap=10000.0)).forEach{bad->assertThrows(IllegalArgumentException::class.java){BoltCircle.solve(bad)}}
 }
 @Test fun coordinateOracleAcrossAllUnknowns(){
  val random=Random(27)
  repeat(500){
   val n=random.nextInt(2,361);val b=random.nextDouble(1.0,10000.0);val angle=random.nextDouble(-720.0,720.0)
   // Obtain chord from two independent Cartesian circle points, not the span formula.
   val r=b/2;val a=Math.toRadians(angle);val t=a+2*PI/n
   val chord=hypot(r*cos(t)-r*cos(a),r*sin(t)-r*sin(a));val d=chord*.2;val gap=chord-d
   val fromGap=BoltCircle.solve(Inputs(count=n,hole=d,gap=gap,firstAngle=angle));close(b,fromGap.bc)
   close(gap,BoltCircle.solve(Inputs(count=n,bc=b,hole=d)).gap)
   close(d,BoltCircle.solve(Inputs(count=n,bc=b,gap=gap)).hole)
   assertEquals(n,BoltCircle.solve(Inputs(bc=b,hole=d,gap=gap)).count)
   val p=fromGap.point(0);close(r*cos(a),p.x);close(r*sin(a),p.y)
  }
 }
 @Test fun unitScalingAndAngleNormalization(){
  close(25.4,LengthUnit.INCH.canonical(1.0));close(.5,LengthUnit.INCH.display(12.7))
  val r=BoltCircle.solve(Inputs(count=6,hole=12.7,gap=50.8));close(127.0,r.bc);close(63.5,r.chord)
  close(90.0,BoltCircle.normalize(450.0));close(270.0,BoltCircle.normalize(-450.0));close(0.0,BoltCircle.normalize(360.0))
 }
}
